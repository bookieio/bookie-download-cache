ArraySort
=========

ArraySort is a beta Component. It provides a case-insensitive Array sort
comparator. Future versions may add additional comparator implementations.
