AsyncQueue
==========

The AsyncQueue module allows you to create a chain of function callbacks
executed in order via setTimeout.  It also supports timeout chained iterations
for each item in the queue as well as promotion, deletion, and other
functionality.
