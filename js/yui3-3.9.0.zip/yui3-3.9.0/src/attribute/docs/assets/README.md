Documentation Assets
====================

Original, full size, images and `psd` files used in constructing final `png` and
`jpg` files, can be found at:

https://github.com/yui/yui-assets/tree/master/components/attribute/docs
