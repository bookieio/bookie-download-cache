Cache
=====

Provides a basic caching mechanism for storing key/value pairs in local
JavaScript memory. As a subclass of `Plugin`, it is designed to seamlessly
integrate with other components (e.g. `DataSource`).
