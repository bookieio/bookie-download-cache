{
    // ARIA live region notifications.
    item_selected  : "{item} selected.",
    items_available: "Suggestions are available. Use the up and down arrow keys to select suggestions."
}
