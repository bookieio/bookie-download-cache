{
    // ARIA live region notifications.
    item_selected  : "{item} seleccionado.",
    items_available: "Hay sugerencias disponibles.  Use flecha arriba y abajo para seleccionar."
}
