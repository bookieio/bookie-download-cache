AutoComplete
============

Provides automatic input completion or suggestions for text input fields and
textareas.
