{
    weekdays : ["Domingo", "Segunda", "Ter\u00E7a", "Quarta", "Quinta", "Sexta", "S\u00E1bado"],
    short_weekdays : ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"],
    very_short_weekdays : ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"],
    first_weekday : 0,
    weekends : [0,6]
}
