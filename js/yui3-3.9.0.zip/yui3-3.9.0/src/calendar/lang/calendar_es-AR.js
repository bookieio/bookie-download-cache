{
    weekdays : ["Domingo", "Lunes", "Martes", "Mi\u00E9rcoles", "Jueves", "Viernes", "S\u00E1bado"],
    short_weekdays : ["Dom", "Lun", "Mar", "Mie", "Jue", "Vie", "Sab"],
    very_short_weekdays : ["Do", "Lu", "Ma", "Mi", "Ju", "Vi", "Sa"]
}

