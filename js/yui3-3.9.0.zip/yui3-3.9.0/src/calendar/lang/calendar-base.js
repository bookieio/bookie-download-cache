{
    weekdays : ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
    short_weekdays : ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
    very_short_weekdays : ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
    first_weekday : 0,
    weekends : [0,6]
}