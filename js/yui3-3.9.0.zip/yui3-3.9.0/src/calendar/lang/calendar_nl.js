{
    weekdays : ["zondag", "maandag", "dinsdag", "woensdag", "donderdag", "vrijdag", "zaterdag"],
    short_weekdays : ["zon", "maan", "dins", "woens", "don", "vrij", "zat"],
    very_short_weekdays : ["zo", "ma", "di", "woe", "do", "vr", "za"]
}
