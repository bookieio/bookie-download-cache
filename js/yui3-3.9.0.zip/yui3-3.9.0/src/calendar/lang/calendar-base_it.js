{
    weekdays : ["Domenica", "Luned\u00EC", "Marted\u00EC", "Mercoled\u00EC", "Gioved\u00EC", "Venerd\u00EC", "Sabato"],
    short_weekdays : ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"],
    very_short_weekdays : ["Do", "Lu", "Ma", "Me", "Gi", "Ve", "Sa"],
    first_weekday : 1,
    weekends : [0,6]
}
