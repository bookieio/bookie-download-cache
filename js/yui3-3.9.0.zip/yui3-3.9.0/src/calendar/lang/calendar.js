{
    weekdays : ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
    short_weekdays : ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    very_short_weekdays : ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"]
}