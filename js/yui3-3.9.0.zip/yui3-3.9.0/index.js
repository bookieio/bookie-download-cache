exports.path = function() {
    return __dirname;
};

exports.YUI = require('./build/yui-nodejs/yui-nodejs').YUI;
