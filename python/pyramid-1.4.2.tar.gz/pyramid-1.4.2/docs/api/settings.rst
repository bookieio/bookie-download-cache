.. _settings_module:

:mod:`pyramid.settings`
--------------------------

.. automodule:: pyramid.settings

  .. autofunction:: asbool

  .. autofunction:: aslist


