.. _threadlocal_module:

:mod:`pyramid.threadlocal`
-------------------------------

.. automodule:: pyramid.threadlocal

   .. autofunction:: get_current_request()

   .. autofunction:: get_current_registry()

