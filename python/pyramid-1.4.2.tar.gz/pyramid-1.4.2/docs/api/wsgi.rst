.. _wsgi_module:

:mod:`pyramid.wsgi`
--------------------------

.. automodule:: pyramid.wsgi

  .. autofunction:: wsgiapp

  .. autofunction:: wsgiapp2
