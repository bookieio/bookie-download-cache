===========================
 celery.backends
===========================

.. contents::
    :local:
.. currentmodule:: celery.backends

.. automodule:: celery.backends
    :members:
    :undoc-members:
