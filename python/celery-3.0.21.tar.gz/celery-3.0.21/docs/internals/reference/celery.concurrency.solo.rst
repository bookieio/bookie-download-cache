===================================================================
 celery.concurrency.solo
===================================================================

.. contents::
    :local:
.. currentmodule:: celery.concurrency.solo

.. automodule:: celery.concurrency.solo
    :members:
    :undoc-members:
