.. _tut-otherqueues:

==========================================================
 Using Celery with Redis/Database as the messaging queue.
==========================================================

.. _otherqueues-redis:

Redis
=====

This section has been moved to :ref:`broker-redis`.

.. _otherqueues-sqlalchemy:

SQLAlchemy
==========

This section has been moved to :ref:`broker-sqlalchemy`.

.. _otherqueues-django:

Django Database
===============

This section has been moved to :ref:`broker-django`.
