1.0.3 -- 2012-01-17
-------------------

- Rename ``chardet.py`` script to ``charade``
