'''Deprecated tokenizers module. Import ``textblob.tokenizers`` instead.
'''

from textblob.tokenizers import *
