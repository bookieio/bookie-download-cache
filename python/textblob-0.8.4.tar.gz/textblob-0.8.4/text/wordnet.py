# -*- coding: utf-8 -*-
'''Deprecated wordnet module. Import ``textblob.wordnet`` instead.
'''

from textblob.wordnet import *
