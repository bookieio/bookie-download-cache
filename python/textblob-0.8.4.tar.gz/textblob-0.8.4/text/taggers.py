# -*- coding: utf-8 -*-
'''Deprecated taggers module. Import ``textblob.taggers`` instead.
'''

from textblob.taggers import *
