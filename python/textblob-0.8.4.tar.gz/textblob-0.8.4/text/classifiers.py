# -*- coding: utf-8 -*-
'''Deprecated classifiers module. Import ``textblob.classifiers`` instead.
'''

from textblob.classifiers import *
