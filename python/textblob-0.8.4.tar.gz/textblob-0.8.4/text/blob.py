# -*- coding: utf-8 -*-
'''Deprecate TextBlob module. Import ``textblob`` instead.
'''

from textblob.blob import *
