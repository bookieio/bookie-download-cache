# -*- coding: utf-8 -*-
'''Deprecated np_extractors module. Import ``textblob.np_extractors`` instead.
'''

from textblob.np_extractors import *
