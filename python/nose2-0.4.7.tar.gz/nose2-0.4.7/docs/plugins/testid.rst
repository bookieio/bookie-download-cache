==============
Using Test IDs
==============

.. autoplugin :: nose2.plugins.testid.TestId

