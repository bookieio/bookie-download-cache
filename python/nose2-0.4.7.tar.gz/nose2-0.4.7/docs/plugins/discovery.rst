======================
Loader: Test discovery
======================

.. autoplugin :: nose2.plugins.loader.discovery.DiscoveryLoader
