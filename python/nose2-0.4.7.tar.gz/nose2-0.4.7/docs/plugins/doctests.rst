================
Loader: Doctests
================

.. autoplugin :: nose2.plugins.doctests.DocTestLoader


