=====================
Buffering test output
=====================

.. autoplugin :: nose2.plugins.buffer.OutputBufferPlugin
