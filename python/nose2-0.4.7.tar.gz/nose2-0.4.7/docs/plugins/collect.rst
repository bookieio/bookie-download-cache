=====================================
Collecting tests without running them
=====================================

.. autoplugin :: nose2.plugins.collect.CollectOnly

