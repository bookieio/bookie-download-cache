===================================
Mapping exceptions to test outcomes
===================================

.. autoplugin :: nose2.plugins.outcomes.Outcomes

