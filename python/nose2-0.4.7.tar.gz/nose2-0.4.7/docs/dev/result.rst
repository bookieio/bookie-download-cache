============
nose2.result
============

.. automodule :: nose2.result
   :members:
