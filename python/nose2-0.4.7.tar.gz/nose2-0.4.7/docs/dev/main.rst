==========
nose2.main
==========

.. automodule :: nose2.main
   :members:
