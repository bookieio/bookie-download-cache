=========
Internals
=========

Reference material for things you probably only need to care about if
you want to contribute to nose2.

.. toctree::
   :maxdepth: 2

   main
   compat
   exceptions
   loader
   result
   runner
   utils
