============================
``support.bitvector`` module
============================

.. automodule:: whoosh.support.bitvector


Base class
==========

.. autoclass:: DocIdSet
    :members:


Implementation classes
======================

.. autoclass:: BitSet
.. autoclass:: SortedIntSet

