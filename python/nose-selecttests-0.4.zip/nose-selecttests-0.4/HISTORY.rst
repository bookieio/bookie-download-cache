History
-------

0.4 (2013-08-27)
================

- Fixed bug to avoid running class fixtures if a test is not selected.
  [Philippe Ombredanne]

- Added PluginTester tests
  [Philippe Ombredanne]


0.3 (2012/12/29)
================

- Removed code for excluding tests (-e already does that)
  [Domen Kožar]

- Don't select all tests that have None as test name (could be a module level SkipTest)
  [Domen Kožar]


0.2 (2012/07/27)
================

- Report SyntaxErrors instead of crashing
  [Domen Kožar]


0.1 (2012/07/08)
================

- initial release
  [Domen Kožar]
