`Mako <http://www.makotemplates.org/>`_ bindings for Pyramid
============================================================

These are bindings for the `Mako templating system
<http://www.makotemplates.org/>`_ for the `Pyramid
<http://docs.pylonsproject.org/en/latest/docs/pyramid.html/>`_ web framework.
