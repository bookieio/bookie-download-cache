class InvalidData(Exception):
    pass


class InvalidInterface(InvalidData):
    pass


class InvalidTimestamp(InvalidData):
    pass
