app = window.app = {
    config: {},
    templates: {},
    utils: {}
};
