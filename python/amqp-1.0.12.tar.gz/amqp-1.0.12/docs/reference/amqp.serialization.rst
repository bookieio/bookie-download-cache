=====================================================
 amqp.serialization
=====================================================

.. contents::
    :local:
.. currentmodule:: amqp.serialization

.. automodule:: amqp.serialization
    :members:
    :undoc-members:
