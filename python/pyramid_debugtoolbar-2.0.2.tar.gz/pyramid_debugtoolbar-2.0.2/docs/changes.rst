.. _changes:

Change history
==============

.. include:: ../CHANGES.txt
